"use client";

import React, { useState, useRef, useEffect } from "react";
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  Camera,
  CameraOff,
  Play,
  Square,
  CheckCircle2,
  AlertCircle,
  Brain,
  Eye,
  Smile,
  Clock,
  Volume2,
  TrendingUp,
  Award,
  Zap,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const AIVideoInterview = () => {
  const [isInterviewStarted, setIsInterviewStarted] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [stream, setStream] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [recordedChunks, setRecordedChunks] = useState([]);
  const [timeRemaining, setTimeRemaining] = useState(120);
  
  const videoRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const timerRef = useRef(null);

  // Mock interview questions
  const questions = [
    {
      id: 1,
      question: "Tell me about yourself and your background.",
      category: "Introduction",
      duration: 120,
    },
    {
      id: 2,
      question: "What are your greatest strengths and how do they apply to this role?",
      category: "Behavioral",
      duration: 120,
    },
    {
      id: 3,
      question: "Describe a challenging project you worked on and how you overcame obstacles.",
      category: "Experience",
      duration: 180,
    },
    {
      id: 4,
      question: "Where do you see yourself in 5 years?",
      category: "Career Goals",
      duration: 90,
    },
  ];

  // Cleanup stream on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [stream]);

  // Initialize webcam when interview starts
  useEffect(() => {
    const initCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { width: 1280, height: 720 },
          audio: { echoCancellation: true, noiseSuppression: true },
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (error) {
        console.error("Error accessing camera:", error);
        alert("Camera access denied. Please enable camera and microphone permissions in your browser settings.");
      }
    };

    if (isInterviewStarted && !stream) {
      initCamera();
    }
  }, [isInterviewStarted, stream]);

  // Timer countdown
  useEffect(() => {
    if (isRecording && timeRemaining > 0) {
      const interval = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      timerRef.current = interval;

      return () => {
        clearInterval(interval);
      };
    } else if (timeRemaining === 0 && isRecording) {
      handleStopRecording();
    }
  }, [isRecording, timeRemaining]);

  const handleStartInterview = () => {
    setIsInterviewStarted(true);
    setCurrentQuestion(0);
  };

  const analyzeResponse = async () => {
    // Simulate AI analysis with delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    const mockAnalysis = {
      confidence: Math.floor(Math.random() * 20) + 75,
      eyeContact: Math.floor(Math.random() * 20) + 70,
      speechClarity: Math.floor(Math.random() * 15) + 80,
      pace: Math.floor(Math.random() * 20) + 70,
      fillerWords: Math.floor(Math.random() * 5) + 2,
      smileCount: Math.floor(Math.random() * 8) + 3,
      posture: Math.floor(Math.random() * 15) + 75,
      responseLength: Math.floor(timeRemaining / 2),
      keyPoints: [
        "Strong introduction with clear structure",
        "Good examples from past experience",
        "Could improve on specific metrics",
      ],
      suggestions: [
        "Maintain eye contact throughout response",
        "Reduce filler words like 'um' and 'uh'",
        "Include more specific numbers and results",
      ],
      overallScore: Math.floor(Math.random() * 15) + 80,
      skillsRadar: [
        { skill: "Confidence", current: 85, required: 90 },
        { skill: "Communication", current: 78, required: 85 },
        { skill: "Technical", current: 88, required: 80 },
        { skill: "Problem Solving", current: 82, required: 85 },
        { skill: "Team Work", current: 75, required: 80 },
      ],
    };

    setAnalysis(mockAnalysis);
    setIsAnalyzing(false);
  };

  const handleStartRecording = () => {
    if (!stream) {
      alert("Please allow camera access first");
      return;
    }

    try {
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported('video/webm') ? 'video/webm' : 'video/mp4',
      });

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          setRecordedChunks(prev => [...prev, event.data]);
        }
      };

      mediaRecorder.onerror = (event) => {
        console.error("MediaRecorder error:", event);
        alert("Recording error occurred. Please try again.");
        setIsRecording(false);
      };

      mediaRecorder.start(100); // Collect data every 100ms
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);
      setTimeRemaining(questions[currentQuestion].duration);
    } catch (error) {
      console.error("Error starting recording:", error);
      alert("Could not start recording. Please check your browser permissions.");
    }
  };

  const handleStopRecording = async () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      // Clear timer
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      
      // Simulate AI analysis
      setIsAnalyzing(true);
      await analyzeResponse();
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setAnalysis(null);
      setRecordedChunks([]);
      setTimeRemaining(questions[currentQuestion + 1].duration);
    } else {
      // Interview complete
      setIsInterviewStarted(false);
    }
  };

  const toggleVideo = () => {
    if (stream) {
      const videoTrack = stream.getVideoTracks()[0];
      videoTrack.enabled = !videoTrack.enabled;
      setVideoEnabled(videoTrack.enabled);
    }
  };

  const toggleAudio = () => {
    if (stream) {
      const audioTrack = stream.getAudioTracks()[0];
      audioTrack.enabled = !audioTrack.enabled;
      setAudioEnabled(audioTrack.enabled);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Pre-interview setup screen
  if (!isInterviewStarted) {
    return (
      <div className="space-y-8 animate-slide-up">
        <div>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-purple-500/20 mb-4">
            <Video className="w-4 h-4 text-purple-500 animate-pulse" />
            <span className="text-sm font-medium">AI-Powered Interview</span>
          </div>
          <h1 className="text-4xl font-bold gradient-title mb-2">
            Video Interview Simulator
          </h1>
          <p className="text-lg text-muted-foreground">
            Practice interviews with AI analysis of your body language, speech, and responses
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Camera Preview */}
          <Card className="border-2 card-hover">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-purple-500" />
                Camera Setup
              </CardTitle>
              <CardDescription>
                Make sure your camera and microphone are working
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-video bg-secondary rounded-lg overflow-hidden relative">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover mirror"
                />
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  <Button
                    size="icon"
                    variant={videoEnabled ? "default" : "destructive"}
                    onClick={toggleVideo}
                    className="rounded-full"
                  >
                    {videoEnabled ? (
                      <Video className="w-4 h-4" />
                    ) : (
                      <VideoOff className="w-4 h-4" />
                    )}
                  </Button>
                  <Button
                    size="icon"
                    variant={audioEnabled ? "default" : "destructive"}
                    onClick={toggleAudio}
                    className="rounded-full"
                  >
                    {audioEnabled ? (
                      <Mic className="w-4 h-4" />
                    ) : (
                      <MicOff className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mt-4 text-center">
                Position yourself in a well-lit area with a neutral background
              </p>
            </CardContent>
          </Card>

          {/* Interview Info */}
          <div className="space-y-6">
            <Card className="border-2 card-hover">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-purple-500" />
                  What We'll Analyze
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { icon: Eye, label: "Eye Contact", desc: "Maintain engagement with viewer" },
                  { icon: Volume2, label: "Speech Clarity", desc: "Clear and confident delivery" },
                  { icon: Smile, label: "Facial Expressions", desc: "Natural and appropriate emotions" },
                  { icon: Clock, label: "Response Timing", desc: "Pacing and structure" },
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-5 h-5 text-purple-500" />
                    </div>
                    <div>
                      <p className="font-semibold">{item.label}</p>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-2 bg-gradient-to-br from-purple-500/10 to-pink-500/10">
              <CardHeader>
                <CardTitle className="text-lg">Interview Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Questions:</span>
                  <span className="font-semibold">{questions.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Time:</span>
                  <span className="font-semibold">~8 minutes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">AI Analysis:</span>
                  <span className="font-semibold">Real-time</span>
                </div>
              </CardContent>
            </Card>

            <Button
              size="lg"
              className="w-full gradient text-white text-lg py-6"
              onClick={handleStartInterview}
            >
              <Play className="w-5 h-5 mr-2" />
              Start Interview
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Interview in progress
  return (
    <div className="space-y-6 animate-slide-up">
      {/* Progress */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">
            Question {currentQuestion + 1} of {questions.length}
          </h2>
          <p className="text-muted-foreground">
            {questions[currentQuestion].category}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Time Remaining</p>
            <p className={`text-2xl font-bold ${timeRemaining < 30 ? 'text-red-500' : ''}`}>
              {formatTime(timeRemaining)}
            </p>
          </div>
          {isRecording && (
            <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
          )}
        </div>
      </div>

      <Progress 
        value={(currentQuestion / questions.length) * 100} 
        className="h-2"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Video Preview */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-2">
            <CardContent className="p-6">
              <div className="aspect-video bg-secondary rounded-lg overflow-hidden relative mb-4">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover mirror"
                />
                {!isRecording && !analysis && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <div className="text-center text-white">
                      <Play className="w-16 h-16 mx-auto mb-4" />
                      <p className="text-xl font-semibold">Ready to answer?</p>
                      <p className="text-sm opacity-80">Click Start Recording when ready</p>
                    </div>
                  </div>
                )}
                {isAnalyzing && (
                  <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                    <div className="text-center text-white">
                      <Brain className="w-16 h-16 mx-auto mb-4 animate-pulse" />
                      <p className="text-xl font-semibold">Analyzing your response...</p>
                      <p className="text-sm opacity-80">AI is evaluating your performance</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-4">
                <Button
                  size="icon"
                  variant={videoEnabled ? "default" : "destructive"}
                  onClick={toggleVideo}
                  className="rounded-full w-12 h-12"
                >
                  {videoEnabled ? (
                    <Video className="w-5 h-5" />
                  ) : (
                    <VideoOff className="w-5 h-5" />
                  )}
                </Button>
                <Button
                  size="icon"
                  variant={audioEnabled ? "default" : "destructive"}
                  onClick={toggleAudio}
                  className="rounded-full w-12 h-12"
                >
                  {audioEnabled ? (
                    <Mic className="w-5 h-5" />
                  ) : (
                    <MicOff className="w-5 h-5" />
                  )}
                </Button>
                {!isRecording && !analysis && (
                  <Button
                    size="lg"
                    className="gradient text-white px-8"
                    onClick={handleStartRecording}
                  >
                    <Play className="w-5 h-5 mr-2" />
                    Start Recording
                  </Button>
                )}
                {isRecording && (
                  <Button
                    size="lg"
                    variant="destructive"
                    className="px-8"
                    onClick={handleStopRecording}
                  >
                    <Square className="w-5 h-5 mr-2" />
                    Stop Recording
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Analysis Results */}
          {analysis && (
            <Card className="border-2 card-hover">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-purple-500" />
                  AI Analysis Results
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="metrics">
                  <TabsList className="grid grid-cols-3 w-full">
                    <TabsTrigger value="metrics">Metrics</TabsTrigger>
                    <TabsTrigger value="insights">Insights</TabsTrigger>
                    <TabsTrigger value="tips">Tips</TabsTrigger>
                  </TabsList>

                  <TabsContent value="metrics" className="space-y-4 mt-4">
                    {[
                      { label: "Overall Score", value: analysis.overallScore, color: "text-green-500" },
                      { label: "Confidence", value: analysis.confidence, color: "text-blue-500" },
                      { label: "Eye Contact", value: analysis.eyeContact, color: "text-purple-500" },
                      { label: "Speech Clarity", value: analysis.speechClarity, color: "text-pink-500" },
                      { label: "Pacing", value: analysis.pace, color: "text-orange-500" },
                    ].map((metric, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between">
                          <span className="font-medium">{metric.label}</span>
                          <span className={`font-bold ${metric.color}`}>{metric.value}%</span>
                        </div>
                        <Progress value={metric.value} className="h-2" />
                      </div>
                    ))}
                  </TabsContent>

                  <TabsContent value="insights" className="space-y-3 mt-4">
                    {analysis.keyPoints.map((point, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <p className="text-sm">{point}</p>
                      </div>
                    ))}
                  </TabsContent>

                  <TabsContent value="tips" className="space-y-3 mt-4">
                    {analysis.suggestions.map((tip, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <Zap className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                        <p className="text-sm">{tip}</p>
                      </div>
                    ))}
                  </TabsContent>
                </Tabs>

                <Button
                  className="w-full mt-6 gradient text-white"
                  size="lg"
                  onClick={handleNextQuestion}
                >
                  {currentQuestion < questions.length - 1 ? 'Next Question' : 'Finish Interview'}
                  <TrendingUp className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Question Panel */}
        <div className="space-y-6">
          <Card className="border-2 bg-gradient-to-br from-purple-500/10 to-pink-500/10">
            <CardHeader>
              <CardTitle className="text-lg">Current Question</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-medium leading-relaxed">
                {questions[currentQuestion].question}
              </p>
              <div className="mt-4 p-3 bg-secondary/50 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  💡 Take a moment to think before recording
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardHeader>
              <CardTitle className="text-lg">Tips for This Question</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {[
                "Structure your answer clearly",
                "Use specific examples",
                "Be concise and focused",
                "Show enthusiasm",
              ].map((tip, index) => (
                <div key={index} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <p className="text-sm">{tip}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      <style jsx>{`
        .mirror {
          transform: scaleX(-1);
        }
      `}</style>
    </div>
  );
};

export default AIVideoInterview;
