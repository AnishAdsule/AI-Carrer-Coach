"use client";

import React, { useState } from "react";
import {
  Sparkles,
  Target,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Briefcase,
  GraduationCap,
  Clock,
  DollarSign,
  Brain,
  Zap,
  FileText,
  Copy,
  Download,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
} from "recharts";

const JobAnalyzerPage = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [formData, setFormData] = useState({
    jobTitle: "",
    company: "",
    jobDescription: "",
  });
  const [analysis, setAnalysis] = useState(null);

  // Mock user skills for matching
  const userSkills = [
    "React", "Next.js", "TypeScript", "JavaScript", "Node.js",
    "TailwindCSS", "Git", "REST API", "PostgreSQL"
  ];

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    
    // Simulate AI analysis (replace with actual API call)
    setTimeout(() => {
      const mockAnalysis = {
        matchPercentage: 78,
        requiredSkills: [
          "React", "TypeScript", "Next.js", "Node.js", "GraphQL", 
          "PostgreSQL", "AWS", "Docker", "Kubernetes"
        ],
        preferredSkills: [
          "Python", "Machine Learning", "Redis", "Microservices",
          "CI/CD", "Terraform"
        ],
        matchedSkills: ["React", "TypeScript", "Next.js", "Node.js", "PostgreSQL"],
        missingSkills: ["GraphQL", "AWS", "Docker", "Kubernetes"],
        experience: "5+ years in full-stack development",
        education: "Bachelor's degree in Computer Science or related field",
        keyResponsibilities: [
          "Design and implement scalable microservices architecture",
          "Lead frontend development using React and Next.js",
          "Collaborate with cross-functional teams",
          "Mentor junior developers",
          "Participate in code reviews and architectural decisions"
        ],
        benefits: [
          "Competitive salary $140k-180k",
          "Stock options",
          "Health insurance",
          "Remote work flexibility",
          "Professional development budget"
        ],
        redFlags: [
          "Requires on-call rotation",
          "Fast-paced startup environment may lead to long hours"
        ],
        suggestions: [
          "Gain experience with GraphQL - consider online courses or side projects",
          "Learn AWS basics - AWS Cloud Practitioner certification recommended",
          "Familiarize yourself with Docker and containerization",
          "Highlight your React and TypeScript expertise in your resume",
          "Emphasize leadership and mentoring experiences"
        ],
        skillsRadar: [
          { skill: "Frontend", current: 90, required: 85 },
          { skill: "Backend", current: 75, required: 80 },
          { skill: "Cloud/DevOps", current: 40, required: 70 },
          { skill: "Database", current: 70, required: 75 },
          { skill: "Architecture", current: 60, required: 80 },
          { skill: "Leadership", current: 50, required: 65 },
        ]
      };
      setAnalysis(mockAnalysis);
      setIsAnalyzing(false);
    }, 2000);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-8 animate-slide-up">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-purple-500/20 backdrop-blur-sm mb-4">
          <Sparkles className="w-4 h-4 text-purple-500 animate-pulse" />
          <span className="text-sm font-medium">AI-Powered Analysis</span>
        </div>
        <h1 className="text-4xl font-bold gradient-title mb-2">
          Job Description Analyzer
        </h1>
        <p className="text-lg text-muted-foreground">
          Paste any job description and get instant AI-powered insights on your match
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input Form */}
        <Card className="lg:col-span-1 border-2 card-hover">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-purple-500" />
              Job Details
            </CardTitle>
            <CardDescription>
              Enter the job information below
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="jobTitle">Job Title</Label>
              <Input
                id="jobTitle"
                name="jobTitle"
                placeholder="e.g. Senior Full Stack Developer"
                value={formData.jobTitle}
                onChange={handleInputChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="company">Company (Optional)</Label>
              <Input
                id="company"
                name="company"
                placeholder="e.g. TechCorp Inc."
                value={formData.company}
                onChange={handleInputChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="jobDescription">Job Description</Label>
              <Textarea
                id="jobDescription"
                name="jobDescription"
                placeholder="Paste the full job description here..."
                className="min-h-[300px] font-mono text-sm"
                value={formData.jobDescription}
                onChange={handleInputChange}
              />
            </div>

            <Button
              className="w-full gradient text-white"
              size="lg"
              onClick={handleAnalyze}
              disabled={!formData.jobDescription || isAnalyzing}
            >
              {isAnalyzing ? (
                <>
                  <div className="spinner w-4 h-4 mr-2" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Analyze with AI
                </>
              )}
            </Button>

            {analysis && (
              <div className="flex gap-2 pt-4 border-t">
                <Button variant="outline" size="sm" className="flex-1">
                  <Copy className="w-3 h-3 mr-2" />
                  Copy
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  <Download className="w-3 h-3 mr-2" />
                  Export
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Analysis Results */}
        <div className="lg:col-span-2 space-y-6">
          {!analysis && !isAnalyzing && (
            <Card className="border-2 border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-20 h-20 rounded-full bg-purple-500/10 flex items-center justify-center mb-4">
                  <Brain className="w-10 h-10 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold mb-2">Ready to Analyze</h3>
                <p className="text-muted-foreground max-w-md">
                  Enter a job description and click "Analyze with AI" to get instant insights
                  on your match percentage, required skills, and personalized recommendations.
                </p>
              </CardContent>
            </Card>
          )}

          {isAnalyzing && (
            <Card className="border-2">
              <CardContent className="flex flex-col items-center justify-center py-20">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mb-4 animate-pulse">
                  <Zap className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">Analyzing Job Description...</h3>
                <p className="text-muted-foreground mb-4">Our AI is processing the information</p>
                <Progress value={66} className="w-64" />
              </CardContent>
            </Card>
          )}

          {analysis && (
            <>
              {/* Match Score */}
              <Card className="border-2 card-hover overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-pink-500/10 pointer-events-none" />
                <CardContent className="p-8 relative">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="text-lg font-semibold text-muted-foreground mb-2">
                        Overall Match Score
                      </h3>
                      <div className="flex items-baseline gap-2">
                        <span className="text-6xl font-bold gradient-title">
                          {analysis.matchPercentage}%
                        </span>
                        <span className="text-2xl text-muted-foreground">/ 100</span>
                      </div>
                    </div>
                    <div className="w-32 h-32 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                      <Target className="w-16 h-16 text-white" />
                    </div>
                  </div>
                  <Progress value={analysis.matchPercentage} className="h-3" />
                  <p className="text-sm text-muted-foreground mt-4">
                    {analysis.matchPercentage >= 80
                      ? "Excellent match! You're a strong candidate for this role."
                      : analysis.matchPercentage >= 60
                      ? "Good match! Focus on bridging the skill gaps highlighted below."
                      : "Fair match. Consider upskilling in key areas before applying."}
                  </p>
                </CardContent>
              </Card>

              {/* Tabs for detailed analysis */}
              <Tabs defaultValue="skills" className="space-y-6">
                <TabsList className="glass w-full justify-start overflow-x-auto">
                  <TabsTrigger value="skills">Skills Match</TabsTrigger>
                  <TabsTrigger value="requirements">Requirements</TabsTrigger>
                  <TabsTrigger value="insights">Insights</TabsTrigger>
                  <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                </TabsList>

                {/* Skills Match Tab */}
                <TabsContent value="skills" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Matched Skills */}
                    <Card className="border-2 card-hover">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-green-500">
                          <CheckCircle2 className="w-5 h-5" />
                          Matched Skills ({analysis.matchedSkills.length})
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-2">
                          {analysis.matchedSkills.map((skill) => (
                            <Badge
                              key={skill}
                              className="bg-green-500/10 text-green-500 border-green-500/20"
                            >
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Missing Skills */}
                    <Card className="border-2 card-hover">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-orange-500">
                          <XCircle className="w-5 h-5" />
                          Missing Skills ({analysis.missingSkills.length})
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-2">
                          {analysis.missingSkills.map((skill) => (
                            <Badge
                              key={skill}
                              className="bg-orange-500/10 text-orange-500 border-orange-500/20"
                            >
                              <XCircle className="w-3 h-3 mr-1" />
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Skills Radar Chart */}
                  <Card className="border-2 card-hover">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="w-5 h-5 text-purple-500" />
                        Skills Comparison
                      </CardTitle>
                      <CardDescription>
                        Your current skills vs. job requirements
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-[400px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <RadarChart data={analysis.skillsRadar}>
                            <PolarGrid />
                            <PolarAngleAxis dataKey="skill" />
                            <PolarRadiusAxis angle={90} domain={[0, 100]} />
                            <Radar
                              name="Your Skills"
                              dataKey="current"
                              stroke="#8b5cf6"
                              fill="#8b5cf6"
                              fillOpacity={0.6}
                            />
                            <Radar
                              name="Required"
                              dataKey="required"
                              stroke="#ec4899"
                              fill="#ec4899"
                              fillOpacity={0.6}
                            />
                          </RadarChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="flex justify-center gap-6 mt-4">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-purple-500" />
                          <span className="text-sm">Your Skills</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-pink-500" />
                          <span className="text-sm">Required</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Requirements Tab */}
                <TabsContent value="requirements" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="border-2 card-hover">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Clock className="w-5 h-5 text-blue-500" />
                          Experience Required
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-lg">{analysis.experience}</p>
                      </CardContent>
                    </Card>

                    <Card className="border-2 card-hover">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <GraduationCap className="w-5 h-5 text-purple-500" />
                          Education Required
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-lg">{analysis.education}</p>
                      </CardContent>
                    </Card>
                  </div>

                  <Card className="border-2 card-hover">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Briefcase className="w-5 h-5 text-purple-500" />
                        Key Responsibilities
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-3">
                        {analysis.keyResponsibilities.map((resp, index) => (
                          <li key={index} className="flex items-start gap-3">
                            <div className="w-6 h-6 rounded-full bg-purple-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="text-xs font-bold text-purple-500">
                                {index + 1}
                              </span>
                            </div>
                            <span>{resp}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Insights Tab */}
                <TabsContent value="insights" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="border-2 card-hover">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-green-500">
                          <DollarSign className="w-5 h-5" />
                          Benefits & Perks
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {analysis.benefits.map((benefit, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                              <span className="text-sm">{benefit}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="border-2 card-hover">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-orange-500">
                          <AlertTriangle className="w-5 h-5" />
                          Potential Red Flags
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {analysis.redFlags.map((flag, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
                              <span className="text-sm">{flag}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                {/* Suggestions Tab */}
                <TabsContent value="suggestions" className="space-y-6">
                  <Card className="border-2 card-hover">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-500" />
                        AI Recommendations
                      </CardTitle>
                      <CardDescription>
                        Personalized suggestions to improve your application
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-4">
                        {analysis.suggestions.map((suggestion, index) => (
                          <li
                            key={index}
                            className="flex items-start gap-3 p-4 rounded-lg hover:bg-secondary/50 transition-colors"
                          >
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                              <span className="text-white text-sm font-bold">
                                {index + 1}
                              </span>
                            </div>
                            <div className="flex-1">
                              <p>{suggestion}</p>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobAnalyzerPage;
