"use client";

import React, { useState, useEffect } from "react";
import {
  Brain,
  Target,
  TrendingUp,
  Award,
  Sparkles,
  ChevronRight,
  CheckCircle2,
  Clock,
  DollarSign,
  Users,
  BookOpen,
  Zap,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const AICareerRecommendations = ({ userProfile }) => {
  const [recommendations, setRecommendations] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate AI analysis
    setTimeout(() => {
      setRecommendations(generateRecommendations(userProfile));
      setIsLoading(false);
    }, 1500);
  }, [userProfile]);

  const generateRecommendations = (profile) => {
    // AI-powered career recommendations based on user profile
    return {
      topCareerPaths: [
        {
          title: "Senior Full Stack Developer",
          matchScore: 92,
          salaryRange: "$120k - $180k",
          demand: "Very High",
          timeToReady: "3-6 months",
          description: "Lead development of complex web applications using modern tech stack",
          requiredSkills: ["React", "Node.js", "TypeScript", "AWS", "Docker"],
          yourSkills: ["React", "Node.js", "TypeScript"],
          missingSkills: ["AWS", "Docker"],
          growth: "+45%",
          companies: ["Google", "Microsoft", "Amazon", "Stripe"],
        },
        {
          title: "Frontend Architect",
          matchScore: 88,
          salaryRange: "$130k - $200k",
          demand: "High",
          timeToReady: "6-12 months",
          description: "Design and implement scalable frontend architectures",
          requiredSkills: ["React", "Vue", "Architecture", "Performance", "Leadership"],
          yourSkills: ["React", "Performance"],
          missingSkills: ["Vue", "Architecture", "Leadership"],
          growth: "+38%",
          companies: ["Netflix", "Airbnb", "Uber", "Meta"],
        },
        {
          title: "DevOps Engineer",
          matchScore: 75,
          salaryRange: "$110k - $160k",
          demand: "Very High",
          timeToReady: "6-9 months",
          description: "Automate infrastructure and improve deployment pipelines",
          requiredSkills: ["AWS", "Docker", "Kubernetes", "CI/CD", "Python"],
          yourSkills: ["Docker", "Python"],
          missingSkills: ["AWS", "Kubernetes", "CI/CD"],
          growth: "+52%",
          companies: ["Amazon", "Google Cloud", "DigitalOcean", "HashiCorp"],
        },
      ],
      alternativePaths: [
        {
          title: "Technical Product Manager",
          matchScore: 70,
          reason: "Your technical skills + communication abilities",
          timeToReady: "6-12 months",
        },
        {
          title: "Solutions Architect",
          matchScore: 68,
          reason: "Strong technical foundation + system design",
          timeToReady: "12+ months",
        },
      ],
      industryRecommendations: [
        { name: "Tech/SaaS", score: 95, reason: "Perfect skill match" },
        { name: "FinTech", score: 88, reason: "High demand for your skills" },
        { name: "E-commerce", score: 82, reason: "Growing rapidly" },
      ],
      nextSteps: [
        {
          step: "Complete AWS Certified Solutions Architect",
          priority: "High",
          impact: "Unlocks 15+ job opportunities",
          time: "2-3 months",
        },
        {
          step: "Build 2-3 full-stack projects with microservices",
          priority: "High",
          impact: "Demonstrates advanced skills",
          time: "1-2 months",
        },
        {
          step: "Contribute to open source projects",
          priority: "Medium",
          impact: "Increases visibility and credibility",
          time: "Ongoing",
        },
        {
          step: "Network with senior engineers",
          priority: "Medium",
          impact: "Referrals and mentorship",
          time: "Ongoing",
        },
      ],
    };
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Brain className="w-16 h-16 text-purple-500 animate-pulse mb-4" />
        <h3 className="text-xl font-bold mb-2">AI is Analyzing Your Profile...</h3>
        <p className="text-muted-foreground">Generating personalized career recommendations</p>
        <Progress value={66} className="w-64 mt-4" />
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-slide-up">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-purple-500/20 mb-4">
          <Sparkles className="w-4 h-4 text-purple-500 animate-pulse" />
          <span className="text-sm font-medium">AI-Powered Career Intelligence</span>
        </div>
        <h1 className="text-4xl font-bold gradient-title mb-2">
          Career Recommendations
        </h1>
        <p className="text-lg text-muted-foreground">
          Based on your skills, interests, and market trends
        </p>
      </div>

      {/* Top Career Paths */}
      <div>
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Target className="w-6 h-6 text-purple-500" />
          Top Career Paths for You
        </h2>
        <div className="grid grid-cols-1 gap-6">
          {recommendations.topCareerPaths.map((career, index) => (
            <Card key={index} className="card-hover border-2 relative overflow-hidden">
              <div className={`absolute top-0 left-0 w-1 h-full bg-gradient-to-b ${
                index === 0 ? 'from-green-500 to-emerald-500' :
                index === 1 ? 'from-blue-500 to-cyan-500' :
                'from-orange-500 to-yellow-500'
              }`} />
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <CardTitle className="text-2xl">{career.title}</CardTitle>
                      {index === 0 && (
                        <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white">
                          Best Match
                        </Badge>
                      )}
                    </div>
                    <CardDescription className="text-base">
                      {career.description}
                    </CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold gradient-title mb-1">
                      {career.matchScore}%
                    </div>
                    <p className="text-xs text-muted-foreground">Match Score</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Key Metrics */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-green-500" />
                    <div>
                      <p className="text-xs text-muted-foreground">Salary</p>
                      <p className="font-semibold text-sm">{career.salaryRange}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-blue-500" />
                    <div>
                      <p className="text-xs text-muted-foreground">Demand</p>
                      <p className="font-semibold text-sm">{career.demand}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-orange-500" />
                    <div>
                      <p className="text-xs text-muted-foreground">Time Ready</p>
                      <p className="font-semibold text-sm">{career.timeToReady}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-purple-500" />
                    <div>
                      <p className="text-xs text-muted-foreground">Growth</p>
                      <p className="font-semibold text-sm text-green-500">{career.growth}</p>
                    </div>
                  </div>
                </div>

                {/* Skills Match */}
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-semibold mb-2 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      Your Matching Skills ({career.yourSkills.length})
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {career.yourSkills.map((skill, i) => (
                        <Badge key={i} className="bg-green-500/10 text-green-600 border-green-500/20">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-semibold mb-2 flex items-center gap-2">
                      <Target className="w-4 h-4 text-orange-500" />
                      Skills to Develop ({career.missingSkills.length})
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {career.missingSkills.map((skill, i) => (
                        <Badge key={i} variant="outline" className="border-orange-500/50 text-orange-600">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Top Companies */}
                <div>
                  <p className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <Users className="w-4 h-4 text-purple-500" />
                    Top Hiring Companies
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {career.companies.map((company, i) => (
                      <Badge key={i} variant="secondary">
                        {company}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Button className="w-full gradient text-white" size="lg">
                  Create Learning Roadmap
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Alternative Paths */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-purple-500" />
            Alternative Career Paths to Consider
          </CardTitle>
          <CardDescription>
            Other options based on your transferable skills
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {recommendations.alternativePaths.map((path, index) => (
            <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors">
              <div className="flex-1">
                <h4 className="font-semibold">{path.title}</h4>
                <p className="text-sm text-muted-foreground">{path.reason}</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Match</p>
                  <p className="text-lg font-bold text-purple-500">{path.matchScore}%</p>
                </div>
                <Button variant="outline" size="sm">
                  Explore
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Industry Recommendations */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-500" />
            Best Industries for Your Profile
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recommendations.industryRecommendations.map((industry, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      index === 0 ? 'bg-green-500/10' :
                      index === 1 ? 'bg-blue-500/10' :
                      'bg-orange-500/10'
                    }`}>
                      <Award className={`w-5 h-5 ${
                        index === 0 ? 'text-green-500' :
                        index === 1 ? 'text-blue-500' :
                        'text-orange-500'
                      }`} />
                    </div>
                    <div>
                      <p className="font-semibold">{industry.name}</p>
                      <p className="text-sm text-muted-foreground">{industry.reason}</p>
                    </div>
                  </div>
                  <span className="text-xl font-bold gradient-title">{industry.score}%</span>
                </div>
                <Progress value={industry.score} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Next Steps */}
      <Card className="border-2 bg-gradient-to-br from-purple-500/10 to-pink-500/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-purple-500" />
            Your Personalized Action Plan
          </CardTitle>
          <CardDescription>
            Follow these steps to reach your career goals
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recommendations.nextSteps.map((step, index) => (
              <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-background hover:bg-secondary/50 transition-colors">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold">{index + 1}</span>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold">{step.step}</h4>
                    <Badge className={
                      step.priority === 'High' ? 'bg-red-500/10 text-red-600' : 'bg-blue-500/10 text-blue-600'
                    }>
                      {step.priority} Priority
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{step.impact}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span>{step.time}</span>
                    </div>
                  </div>
                </div>
                <Button size="sm">
                  Start
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AICareerRecommendations;
