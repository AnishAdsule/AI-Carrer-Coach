import { getIndustryInsights } from "@/actions/dashboard";
import DashboardView from "./_component/dashboard-view";
import { getUserOnboardingStatus } from "@/actions/user";
import { redirect } from "next/navigation";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Video, 
  Briefcase, 
  Search, 
  FileText, 
  PenBox, 
  GraduationCap,
  ArrowRight,
  Sparkles,
} from "lucide-react";

export default async function DashboardPage() {
  const { isOnboarded } = await getUserOnboardingStatus();

  // If not onboarded, redirect to onboarding page
  // Skip this check if already on the onboarding page
  if (!isOnboarded) {
    redirect("/onboarding");
  }

  const insights = await getIndustryInsights();

  const quickAccessTools = [
    {
      title: "AI Video Interview",
      description: "Practice with AI-powered video analysis",
      icon: Video,
      href: "/ai-interview",
      gradient: "from-purple-500 to-pink-500",
      badge: "NEW",
    },
    {
      title: "Track Applications",
      description: "Manage job applications on Kanban board",
      icon: Briefcase,
      href: "/applications",
      gradient: "from-blue-500 to-cyan-500",
      badge: "Phase 1",
    },
    {
      title: "Job Analyzer",
      description: "Get AI insights on job descriptions",
      icon: Search,
      href: "/job-analyzer",
      gradient: "from-green-500 to-emerald-500",
      badge: "Phase 1",
    },
    {
      title: "Resume Builder",
      description: "Create ATS-optimized resumes",
      icon: FileText,
      href: "/resume",
      gradient: "from-orange-500 to-red-500",
    },
    {
      title: "Cover Letter",
      description: "Generate personalized cover letters",
      icon: PenBox,
      href: "/ai-cover-letter",
      gradient: "from-pink-500 to-rose-500",
    },
    {
      title: "Interview Prep",
      description: "Practice common interview questions",
      icon: GraduationCap,
      href: "/interview",
      gradient: "from-indigo-500 to-purple-500",
    },
  ];

  return (
    <div className="container mx-auto space-y-8">
      {/* Welcome Section */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-purple-500/20 mb-4">
          <Sparkles className="w-4 h-4 text-purple-500 animate-pulse" />
          <span className="text-sm font-medium">AI-Powered Career Growth</span>
        </div>
        <h1 className="text-4xl font-bold gradient-title">Career Dashboard</h1>
        <p className="text-lg text-muted-foreground">
          Your command center for career success
        </p>
      </div>

      {/* Quick Access Tools */}
      <div>
        <h2 className="text-2xl font-bold mb-4">Quick Access Tools</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quickAccessTools.map((tool, index) => {
            const Icon = tool.icon;
            return (
              <Link key={index} href={tool.href}>
                <Card className="card-hover border-2 h-full relative overflow-hidden group">
                  {tool.badge && (
                    <div className="absolute top-4 right-4 z-10">
                      <span className="px-2 py-1 text-xs font-bold bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full">
                        {tool.badge}
                      </span>
                    </div>
                  )}
                  <div className={`absolute inset-0 bg-gradient-to-br ${tool.gradient} opacity-0 group-hover:opacity-10 transition-opacity`} />
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tool.gradient} flex items-center justify-center mb-3`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="group-hover:text-primary transition-colors">
                      {tool.title}
                    </CardTitle>
                    <CardDescription>{tool.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      variant="ghost" 
                      className="w-full justify-between group-hover:bg-secondary"
                    >
                      Get Started
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Industry Insights */}
      <div>
        <h2 className="text-2xl font-bold mb-4">Industry Insights</h2>
        <DashboardView insights={insights} />
      </div>
    </div>
  );
}
