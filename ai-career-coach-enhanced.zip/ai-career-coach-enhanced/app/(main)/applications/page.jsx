"use client";

import React, { useState } from "react";
import {
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";
import {
  Calendar,
  TrendingUp,
  Target,
  Clock,
  Plus,
  Filter,
  Download,
  Sparkles,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ApplicationBoard from "@/components/application-board";
import { format, subDays, differenceInDays } from "date-fns";

const ApplicationTrackerPage = () => {
  // Mock data - replace with real data from database
  const [applications] = useState([
    {
      id: "1",
      jobTitle: "Senior Frontend Developer",
      company: "TechCorp",
      location: "Remote",
      salary: "$120k-150k",
      status: "interview",
      appliedDate: new Date(2025, 1, 1),
      matchScore: 85,
      jobUrl: "https://example.com/job1",
    },
    {
      id: "2",
      jobTitle: "Full Stack Engineer",
      company: "StartupXYZ",
      location: "San Francisco, CA",
      salary: "$130k-160k",
      status: "applied",
      appliedDate: new Date(2025, 1, 5),
      matchScore: 72,
      jobUrl: "https://example.com/job2",
    },
    {
      id: "3",
      jobTitle: "React Developer",
      company: "BigTech Inc",
      location: "New York, NY",
      salary: "$140k-170k",
      status: "offer",
      appliedDate: new Date(2025, 0, 20),
      matchScore: 91,
      jobUrl: "https://example.com/job3",
    },
    {
      id: "4",
      jobTitle: "Software Engineer",
      company: "Enterprise Co",
      location: "Austin, TX",
      salary: "$110k-140k",
      status: "rejected",
      appliedDate: new Date(2025, 0, 15),
      matchScore: 68,
      jobUrl: "https://example.com/job4",
    },
    {
      id: "5",
      jobTitle: "Frontend Developer",
      company: "MidSize Corp",
      location: "Remote",
      salary: "$100k-130k",
      status: "applied",
      appliedDate: new Date(2025, 1, 8),
      matchScore: 78,
    },
  ]);

  // Calculate analytics
  const totalApplications = applications.length;
  const activeApplications = applications.filter(
    (app) => app.status === "applied" || app.status === "interview"
  ).length;
  const responseRate = applications.length > 0
    ? ((applications.filter(
        (app) => app.status !== "applied"
      ).length / applications.length) * 100).toFixed(1)
    : 0;
  
  const avgResponseTime = applications.length > 0
    ? Math.round(
        applications
          .filter((app) => app.status !== "applied")
          .reduce((acc, app) => {
            return acc + differenceInDays(new Date(), new Date(app.appliedDate));
          }, 0) / applications.filter((app) => app.status !== "applied").length || 1
      )
    : 0;

  // Status distribution for pie chart
  const statusData = [
    { name: "Applied", value: applications.filter(a => a.status === "applied").length, color: "#3b82f6" },
    { name: "Interview", value: applications.filter(a => a.status === "interview").length, color: "#8b5cf6" },
    { name: "Offer", value: applications.filter(a => a.status === "offer").length, color: "#10b981" },
    { name: "Rejected", value: applications.filter(a => a.status === "rejected").length, color: "#ef4444" },
  ].filter(item => item.value > 0);

  // Applications over time for line chart
  const getLast30Days = () => {
    const days = [];
    for (let i = 29; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const count = applications.filter(
        (app) => format(new Date(app.appliedDate), "yyyy-MM-dd") === format(date, "yyyy-MM-dd")
      ).length;
      days.push({
        date: format(date, "MMM dd"),
        applications: count,
      });
    }
    return days;
  };

  const timelineData = getLast30Days();

  // Match score distribution
  const matchScoreData = [
    { range: "80-100%", count: applications.filter(a => a.matchScore >= 80).length },
    { range: "60-79%", count: applications.filter(a => a.matchScore >= 60 && a.matchScore < 80).length },
    { range: "40-59%", count: applications.filter(a => a.matchScore >= 40 && a.matchScore < 60).length },
    { range: "0-39%", count: applications.filter(a => a.matchScore < 40).length },
  ];

  const handleUpdateStatus = (appId, newStatus) => {
    console.log("Update status:", appId, newStatus);
    // TODO: Update in database
  };

  const handleAddApplication = () => {
    console.log("Add new application");
    // TODO: Open modal or navigate to add page
  };

  return (
    <div className="space-y-8 animate-slide-up">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold gradient-title mb-2">
            Application Tracker
          </h1>
          <p className="text-muted-foreground">
            Manage and track all your job applications in one place
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button className="gradient text-white" onClick={handleAddApplication}>
            <Plus className="w-4 h-4 mr-2" />
            Add Application
          </Button>
        </div>
      </div>

      {/* Analytics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="card-hover border-2 bg-gradient-to-br from-card to-card/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Target className="w-5 h-5 text-blue-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold gradient-title">{totalApplications}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {activeApplications} active
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover border-2 bg-gradient-to-br from-card to-card/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Response Rate</CardTitle>
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-purple-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold gradient-title">{responseRate}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              Of applications got response
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover border-2 bg-gradient-to-br from-card to-card/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <Clock className="w-5 h-5 text-green-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold gradient-title">{avgResponseTime}d</div>
            <p className="text-xs text-muted-foreground mt-1">
              Average days to hear back
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover border-2 bg-gradient-to-br from-card to-card/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">This Week</CardTitle>
            <div className="w-10 h-10 rounded-lg bg-pink-500/10 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-pink-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold gradient-title">
              {applications.filter(a => 
                differenceInDays(new Date(), new Date(a.appliedDate)) <= 7
              ).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Applications submitted
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="board" className="space-y-6">
        <TabsList className="glass">
          <TabsTrigger value="board">Kanban Board</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="list">List View</TabsTrigger>
        </TabsList>

        <TabsContent value="board" className="space-y-6">
          <ApplicationBoard
            applications={applications}
            onUpdateStatus={handleUpdateStatus}
            onAddApplication={handleAddApplication}
          />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Application Timeline */}
            <Card className="border-2 card-hover">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-purple-500" />
                  Application Timeline
                </CardTitle>
                <CardDescription>Last 30 days</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={timelineData}>
                      <defs>
                        <linearGradient id="colorApps" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="glass border border-border rounded-lg p-3 shadow-xl">
                                <p className="text-sm font-semibold">{payload[0].payload.date}</p>
                                <p className="text-sm text-purple-500">
                                  {payload[0].value} applications
                                </p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="applications"
                        stroke="#8b5cf6"
                        strokeWidth={3}
                        fill="url(#colorApps)"
                        dot={{ fill: "#8b5cf6", r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Status Distribution */}
            <Card className="border-2 card-hover">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-500" />
                  Status Distribution
                </CardTitle>
                <CardDescription>Current application status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={statusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {statusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  {statusData.map((item) => (
                    <div key={item.name} className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-sm">
                        {item.name} ({item.value})
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Match Score Distribution */}
            <Card className="lg:col-span-2 border-2 card-hover">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-purple-500" />
                  Match Score Distribution
                </CardTitle>
                <CardDescription>
                  How well your applications match your profile
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={matchScoreData}>
                      <defs>
                        <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#ec4899" stopOpacity={0.8}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                      <XAxis dataKey="range" />
                      <YAxis />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="glass border border-border rounded-lg p-3 shadow-xl">
                                <p className="text-sm font-semibold">{payload[0].payload.range}</p>
                                <p className="text-sm text-purple-500">
                                  {payload[0].value} applications
                                </p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar
                        dataKey="count"
                        fill="url(#colorScore)"
                        radius={[8, 8, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="list">
          <Card className="border-2">
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">
                List view coming soon...
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ApplicationTrackerPage;
