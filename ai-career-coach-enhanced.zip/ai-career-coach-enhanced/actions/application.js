"use server";

import { auth } from "@clerk/nextjs";
import prisma from "@/lib/prisma";
import { revalidatePath } from "next/cache";

// Get all applications for current user
export async function getApplications() {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
      include: {
        applications: {
          orderBy: { appliedDate: "desc" },
        },
      },
    });

    if (!user) {
      throw new Error("User not found");
    }

    return { success: true, applications: user.applications };
  } catch (error) {
    console.error("Error fetching applications:", error);
    return { success: false, error: error.message };
  }
}

// Create new application
export async function createApplication(data) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
    });

    if (!user) {
      throw new Error("User not found");
    }

    const application = await prisma.application.create({
      data: {
        userId: user.id,
        jobTitle: data.jobTitle,
        company: data.company,
        location: data.location,
        jobUrl: data.jobUrl,
        jobDescription: data.jobDescription,
        salary: data.salary,
        status: "applied",
        appliedDate: new Date(),
        notes: data.notes || "",
        contacts: data.contacts || [],
        interviews: [],
        documents: [],
      },
    });

    revalidatePath("/applications");
    return { success: true, application };
  } catch (error) {
    console.error("Error creating application:", error);
    return { success: false, error: error.message };
  }
}

// Update application status
export async function updateApplicationStatus(applicationId, newStatus) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
    });

    if (!user) {
      throw new Error("User not found");
    }

    // Verify ownership
    const application = await prisma.application.findFirst({
      where: {
        id: applicationId,
        userId: user.id,
      },
    });

    if (!application) {
      throw new Error("Application not found or unauthorized");
    }

    // Update status with appropriate date
    const updateData = { status: newStatus };
    
    if (newStatus === "interview" && !application.interviewDate) {
      updateData.interviewDate = new Date();
    } else if (newStatus === "offer" && !application.offerDate) {
      updateData.offerDate = new Date();
    } else if (newStatus === "rejected" && !application.rejectedDate) {
      updateData.rejectedDate = new Date();
    }

    const updatedApplication = await prisma.application.update({
      where: { id: applicationId },
      data: updateData,
    });

    revalidatePath("/applications");
    return { success: true, application: updatedApplication };
  } catch (error) {
    console.error("Error updating application:", error);
    return { success: false, error: error.message };
  }
}

// Update application details
export async function updateApplication(applicationId, data) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
    });

    if (!user) {
      throw new Error("User not found");
    }

    // Verify ownership
    const application = await prisma.application.findFirst({
      where: {
        id: applicationId,
        userId: user.id,
      },
    });

    if (!application) {
      throw new Error("Application not found or unauthorized");
    }

    const updatedApplication = await prisma.application.update({
      where: { id: applicationId },
      data: {
        ...data,
        updatedAt: new Date(),
      },
    });

    revalidatePath("/applications");
    return { success: true, application: updatedApplication };
  } catch (error) {
    console.error("Error updating application:", error);
    return { success: false, error: error.message };
  }
}

// Delete application
export async function deleteApplication(applicationId) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
    });

    if (!user) {
      throw new Error("User not found");
    }

    // Verify ownership
    const application = await prisma.application.findFirst({
      where: {
        id: applicationId,
        userId: user.id,
      },
    });

    if (!application) {
      throw new Error("Application not found or unauthorized");
    }

    await prisma.application.delete({
      where: { id: applicationId },
    });

    revalidatePath("/applications");
    return { success: true };
  } catch (error) {
    console.error("Error deleting application:", error);
    return { success: false, error: error.message };
  }
}

// Add interview to application
export async function addInterview(applicationId, interviewData) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
    });

    if (!user) {
      throw new Error("User not found");
    }

    const application = await prisma.application.findFirst({
      where: {
        id: applicationId,
        userId: user.id,
      },
    });

    if (!application) {
      throw new Error("Application not found");
    }

    const interviews = application.interviews || [];
    interviews.push({
      ...interviewData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    });

    const updatedApplication = await prisma.application.update({
      where: { id: applicationId },
      data: { interviews },
    });

    revalidatePath("/applications");
    return { success: true, application: updatedApplication };
  } catch (error) {
    console.error("Error adding interview:", error);
    return { success: false, error: error.message };
  }
}

// Get application statistics
export async function getApplicationStats() {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
      include: {
        applications: true,
      },
    });

    if (!user) {
      throw new Error("User not found");
    }

    const total = user.applications.length;
    const applied = user.applications.filter(app => app.status === "applied").length;
    const interview = user.applications.filter(app => app.status === "interview").length;
    const offer = user.applications.filter(app => app.status === "offer").length;
    const rejected = user.applications.filter(app => app.status === "rejected").length;

    const responseRate = total > 0 
      ? ((total - applied) / total * 100).toFixed(1)
      : 0;

    return {
      success: true,
      stats: {
        total,
        applied,
        interview,
        offer,
        rejected,
        responseRate,
      },
    };
  } catch (error) {
    console.error("Error fetching stats:", error);
    return { success: false, error: error.message };
  }
}
