"use server";

import { auth } from "@clerk/nextjs";
import prisma from "@/lib/prisma";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { revalidatePath } from "next/cache";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Analyze job description with AI
export async function analyzeJobDescription(data) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
    });

    if (!user) {
      throw new Error("User not found");
    }

    // Get user's skills for comparison
    const userSkills = user.skills || [];
    const userExperience = user.experience || 0;

    // Prepare AI prompt
    const prompt = `
You are an expert career counselor and job market analyst. Analyze the following job description and provide detailed insights.

JOB TITLE: ${data.jobTitle}
COMPANY: ${data.company || "Not specified"}
JOB DESCRIPTION:
${data.jobDescription}

USER PROFILE:
- Current Skills: ${userSkills.join(", ") || "Not specified"}
- Years of Experience: ${userExperience}
- Industry: ${user.industry || "Not specified"}

Please analyze this job posting and provide a structured JSON response with the following fields:

{
  "requiredSkills": ["skill1", "skill2", ...], // Must-have skills/technologies
  "preferredSkills": ["skill1", "skill2", ...], // Nice-to-have skills
  "experience": "X+ years in relevant field", // Required experience
  "education": "Degree requirements",
  "matchPercentage": 0-100, // How well the user matches based on their profile
  "matchedSkills": ["skill1", "skill2", ...], // Skills user has that match
  "missingSkills": ["skill1", "skill2", ...], // Required skills user is missing
  "suggestions": ["suggestion1", "suggestion2", ...], // Specific actionable advice
  "keyResponsibilities": ["resp1", "resp2", ...], // Main job duties
  "benefits": ["benefit1", "benefit2", ...], // Perks and benefits mentioned
  "redFlags": ["flag1", "flag2", ...], // Potential concerns or challenges
  "salaryEstimate": "Range if mentioned or estimated based on role and location",
  "workEnvironment": "Remote/Hybrid/On-site and culture indicators"
}

Be specific and actionable in your analysis. Focus on providing value to help the user make informed decisions.
`;

    // Call Gemini AI
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    const result = await model.generateContent(prompt);
    const response = await result.response;
    let analysisText = response.text();

    // Extract JSON from response (remove markdown code blocks if present)
    analysisText = analysisText.replace(/```json\n?/g, "").replace(/```\n?/g, "");
    const analysis = JSON.parse(analysisText);

    // Save analysis to database
    const jobAnalysis = await prisma.jobAnalysis.create({
      data: {
        userId: user.id,
        jobTitle: data.jobTitle,
        company: data.company,
        jobDescription: data.jobDescription,
        requiredSkills: analysis.requiredSkills || [],
        preferredSkills: analysis.preferredSkills || [],
        experience: analysis.experience,
        education: analysis.education,
        matchPercentage: analysis.matchPercentage,
        matchedSkills: analysis.matchedSkills || [],
        missingSkills: analysis.missingSkills || [],
        suggestions: analysis.suggestions || [],
        keyResponsibilities: analysis.keyResponsibilities || [],
        benefits: analysis.benefits || [],
        redFlags: analysis.redFlags || [],
      },
    });

    return {
      success: true,
      analysis: {
        ...analysis,
        id: jobAnalysis.id,
        analyzedAt: jobAnalysis.analyzedAt,
      },
    };
  } catch (error) {
    console.error("Error analyzing job description:", error);
    return { success: false, error: error.message };
  }
}

// Get all job analyses for current user
export async function getJobAnalyses() {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
      include: {
        jobAnalyses: {
          orderBy: { analyzedAt: "desc" },
        },
      },
    });

    if (!user) {
      throw new Error("User not found");
    }

    return { success: true, analyses: user.jobAnalyses };
  } catch (error) {
    console.error("Error fetching job analyses:", error);
    return { success: false, error: error.message };
  }
}

// Get single job analysis
export async function getJobAnalysis(analysisId) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
    });

    if (!user) {
      throw new Error("User not found");
    }

    const analysis = await prisma.jobAnalysis.findFirst({
      where: {
        id: analysisId,
        userId: user.id,
      },
    });

    if (!analysis) {
      throw new Error("Analysis not found");
    }

    return { success: true, analysis };
  } catch (error) {
    console.error("Error fetching job analysis:", error);
    return { success: false, error: error.message };
  }
}

// Delete job analysis
export async function deleteJobAnalysis(analysisId) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
    });

    if (!user) {
      throw new Error("User not found");
    }

    const analysis = await prisma.jobAnalysis.findFirst({
      where: {
        id: analysisId,
        userId: user.id,
      },
    });

    if (!analysis) {
      throw new Error("Analysis not found");
    }

    await prisma.jobAnalysis.delete({
      where: { id: analysisId },
    });

    revalidatePath("/job-analyzer");
    return { success: true };
  } catch (error) {
    console.error("Error deleting job analysis:", error);
    return { success: false, error: error.message };
  }
}

// Create application from analysis
export async function createApplicationFromAnalysis(analysisId) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId: userId },
    });

    if (!user) {
      throw new Error("User not found");
    }

    const analysis = await prisma.jobAnalysis.findFirst({
      where: {
        id: analysisId,
        userId: user.id,
      },
    });

    if (!analysis) {
      throw new Error("Analysis not found");
    }

    const application = await prisma.application.create({
      data: {
        userId: user.id,
        jobTitle: analysis.jobTitle,
        company: analysis.company || "",
        jobDescription: analysis.jobDescription,
        status: "applied",
        appliedDate: new Date(),
        matchScore: analysis.matchPercentage,
        skillsMatch: {
          matched: analysis.matchedSkills,
          missing: analysis.missingSkills,
        },
        notes: `Analysis ID: ${analysisId}\n\nMatch: ${analysis.matchPercentage}%\n\nSuggestions:\n${analysis.suggestions.join('\n- ')}`,
      },
    });

    revalidatePath("/applications");
    return { success: true, application };
  } catch (error) {
    console.error("Error creating application from analysis:", error);
    return { success: false, error: error.message };
  }
}

// Get quick insights on a job URL
export async function quickAnalyzeJobUrl(jobUrl) {
  try {
    const { userId } = await auth();
    if (!userId) {
      throw new Error("Unauthorized");
    }

    // This would typically scrape the job URL or use an API
    // For now, return a placeholder
    return {
      success: true,
      data: {
        title: "Job title will be extracted",
        company: "Company name will be extracted",
        description: "Full description will be fetched",
        location: "Location info",
      },
    };
  } catch (error) {
    console.error("Error analyzing job URL:", error);
    return { success: false, error: error.message };
  }
}
