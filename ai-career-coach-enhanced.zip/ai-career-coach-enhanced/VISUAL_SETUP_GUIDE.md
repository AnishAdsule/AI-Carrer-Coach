# 📸 Visual Setup Guide - Screenshots & Instructions

## 🎯 Follow these exact steps with visual guides

---

## 1️⃣ CLERK SETUP (5 minutes)

### Screenshot 1: Sign Up Page
```
┌─────────────────────────────────────────────────┐
│  clerk                                          │
│                                                 │
│  Welcome to Clerk                               │
│                                                 │
│  [Continue with GitHub]    (Click this)         │
│  [Continue with Google]    (Or this)            │
│                                                 │
│  Or use email:                                  │
│  Email: [________________]                      │
│  [Continue]                                     │
│                                                 │
│  No credit card required ✓                      │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Go to: https://dashboard.clerk.com/sign-up
2. Click "Continue with GitHub" (easiest)
3. Authorize Clerk
4. ✅ You're logged in!

---

### Screenshot 2: Create Application
```
┌─────────────────────────────────────────────────┐
│  Create application                             │
│                                                 │
│  Application name                               │
│  [AI Career Coach]  ← Type this                 │
│                                                 │
│  How will your users sign in?                   │
│  ☑ Email address                                │
│  ☑ Google                                       │
│  ☐ GitHub                                       │
│  ☐ Microsoft                                    │
│                                                 │
│  [Create application]  ← Click                  │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Enter name: "AI Career Coach"
2. Check: Email & Google
3. Click "Create application"
4. ✅ App created!

---

### Screenshot 3: Copy API Keys
```
┌─────────────────────────────────────────────────┐
│  🎉 Your application has been created!          │
│                                                 │
│  Add these keys to your .env file:              │
│                                                 │
│  NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY              │
│  ┌───────────────────────────────────────────┐ │
│  │ pk_test_aW5zcGlyZWQtbW9vc2Utcnkuc2hhc... │ │
│  │ [📋 Copy]  ← Click to copy                │ │
│  └───────────────────────────────────────────┘ │
│                                                 │
│  CLERK_SECRET_KEY                               │
│  ┌───────────────────────────────────────────┐ │
│  │ sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx... │ │
│  │ [📋 Copy]  ← Click to copy                │ │
│  └───────────────────────────────────────────┘ │
│                                                 │
│  [Continue to Dashboard]                        │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Click "Copy" for publishable key
2. Paste in `.env`:
   ```env
   NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
   ```
3. Click "Copy" for secret key
4. Paste in `.env`:
   ```env
   CLERK_SECRET_KEY=sk_test_...
   ```
5. ✅ Clerk configured!

---

## 2️⃣ GOOGLE GEMINI SETUP (3 minutes)

### Screenshot 1: Google AI Studio
```
┌─────────────────────────────────────────────────┐
│  Google AI Studio                    [Sign in]  │
│                                                 │
│  🤖 Build with Gemini                           │
│                                                 │
│  Get started with the Gemini API                │
│                                                 │
│  [Get API key]  ← Click this                    │
│                                                 │
│  Fast • Free • Easy to use                      │
│  60 requests per minute                         │
│  1,500 requests per day                         │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Go to: https://aistudio.google.com/app/apikey
2. Sign in with Google account
3. Click "Get API key"
4. ✅ Proceed to next step

---

### Screenshot 2: Create API Key
```
┌─────────────────────────────────────────────────┐
│  Create API key                                 │
│                                                 │
│  Create API key in new project (recommended)    │
│  ○ Create new project  ← Select this            │
│                                                 │
│  Or use existing project:                       │
│  ○ My Project                                   │
│  ○ Another Project                              │
│                                                 │
│  [Create API key]  ← Click                      │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Select "Create API key in new project"
2. Click "Create API key"
3. ✅ Key will be generated

---

### Screenshot 3: Copy API Key
```
┌─────────────────────────────────────────────────┐
│  Your API key                                   │
│                                                 │
│  ⚠️ Keep this key secure!                       │
│                                                 │
│  ┌───────────────────────────────────────────┐ │
│  │ AIzaSyBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  │ │
│  │ [📋 Copy API key]  ← Click                │ │
│  └───────────────────────────────────────────┘ │
│                                                 │
│  This key has access to:                        │
│  • Gemini Pro                                   │
│  • 60 requests per minute                       │
│  • No credit card required                      │
│                                                 │
│  [Done]                                         │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Click "Copy API key"
2. Paste in `.env`:
   ```env
   GEMINI_API_KEY=AIzaSyBxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
3. Click "Done"
4. ✅ Gemini configured!

**⚠️ IMPORTANT:** Never share this key publicly!

---

## 3️⃣ NEON DATABASE SETUP (4 minutes)

### Screenshot 1: Neon Homepage
```
┌─────────────────────────────────────────────────┐
│  neon                              [Sign up]    │
│                                                 │
│  Serverless Postgres                            │
│  Built for developers                           │
│                                                 │
│  [Get started free]  ← Click                    │
│                                                 │
│  ✓ No credit card required                      │
│  ✓ 10 GB storage                                │
│  ✓ Autoscaling compute                          │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Go to: https://neon.tech
2. Click "Sign up" or "Get started free"
3. Choose sign-up method
4. ✅ Create account

---

### Screenshot 2: Sign Up Options
```
┌─────────────────────────────────────────────────┐
│  Create your Neon account                       │
│                                                 │
│  [Continue with GitHub]  ← Recommended          │
│  [Continue with Google]                         │
│                                                 │
│  Or sign up with email:                         │
│  Email: [________________]                      │
│  Password: [________________]                   │
│  [Sign up]                                      │
│                                                 │
│  No credit card required ✓                      │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Click "Continue with GitHub" (easiest)
2. Authorize Neon
3. ✅ Account created!

---

### Screenshot 3: Create Project
```
┌─────────────────────────────────────────────────┐
│  Create your first project                      │
│                                                 │
│  Project name                                   │
│  [ai-career-coach]  ← Type this                 │
│                                                 │
│  Region                                         │
│  [🇺🇸 US East (Ohio)]  ← Choose closest          │
│   Options:                                      │
│   • US East (Ohio)                              │
│   • US West (Oregon)                            │
│   • EU Central (Frankfurt)                      │
│   • Asia Pacific (Singapore)                    │
│                                                 │
│  Postgres version                               │
│  [15]  ← Default is fine                        │
│                                                 │
│  [Create project]  ← Click                      │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Name: "ai-career-coach"
2. Region: Choose closest to you
3. Leave Postgres version as default
4. Click "Create project"
5. ✅ Wait 10 seconds...

---

### Screenshot 4: Connection String
```
┌─────────────────────────────────────────────────┐
│  ai-career-coach                                │
│                                                 │
│  Connection string                              │
│                                                 │
│  ┌───────────────────────────────────────────┐ │
│  │ postgresql://alex:AbCxxx123@ep-cool-cl... │ │
│  │ ...oud-123456.us-east-2.aws.neon.tech/... │ │
│  │ neondb?sslmode=require                    │ │
│  │                                           │ │
│  │ [📋 Copy]  ← Click to copy all            │ │
│  └───────────────────────────────────────────┘ │
│                                                 │
│  Database: neondb                               │
│  User: alex                                     │
│  Host: ep-cool-cloud-123456.us-east-2.aws...   │
│                                                 │
│  [Dashboard]  [SQL Editor]  [Connection]        │
└─────────────────────────────────────────────────┘
```

**What to do:**
1. Click "Copy" to copy entire connection string
2. Paste in `.env`:
   ```env
   DATABASE_URL="postgresql://alex:AbCxxx123@ep-cool-cloud-123456.us-east-2.aws.neon.tech/neondb?sslmode=require"
   ```
3. **Keep the quotes!** ← Important
4. ✅ Database configured!

---

## 4️⃣ VERIFY YOUR .ENV FILE

### Your .env should look exactly like this:

```env
# Database (Neon) - MUST have quotes!
DATABASE_URL="postgresql://username:password@host.neon.tech/neondb?sslmode=require"

# Clerk Authentication - NO quotes needed
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxxxxxxxxxxxxxx
CLERK_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL=/onboarding
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL=/onboarding

# Google Gemini AI - NO quotes needed
GEMINI_API_KEY=AIzaSyBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Optional
NODE_ENV=development
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### ✅ Checklist:
- [ ] DATABASE_URL has **quotes** around it
- [ ] CLERK keys start with `pk_test_` and `sk_test_`
- [ ] GEMINI_API_KEY starts with `AIzaSy`
- [ ] No extra spaces or line breaks
- [ ] File is named exactly `.env` (not .env.txt)

---

## 5️⃣ RUN THE SETUP

### Open Terminal in Project Folder

**Mac/Linux:**
```bash
cd ai-career-coach-enhanced
```

**Windows (Command Prompt):**
```cmd
cd ai-career-coach-enhanced
```

**Windows (PowerShell):**
```powershell
cd ai-career-coach-enhanced
```

---

### Run These Commands One by One:

```bash
# 1. Install dependencies (takes 1-2 minutes)
npm install
```
✅ Should see: "added 500 packages"

```bash
# 2. Generate Prisma Client
npx prisma generate
```
✅ Should see: "Generated Prisma Client"

```bash
# 3. Push database schema (creates tables)
npx prisma db push
```
✅ Should see: "Your database is now in sync"

```bash
# 4. Start development server
npm run dev
```
✅ Should see:
```
  ▲ Next.js 15.1.4
  - Local:        http://localhost:3000
  - Network:      http://192.168.1.x:3000

 ✓ Ready in 2.5s
```

---

## 6️⃣ TEST EVERYTHING

### Test 1: Open the App
```
Browser → http://localhost:3000
```
✅ Should see: Beautiful landing page with purple gradients

---

### Test 2: Sign Up
```
Click "Get Started" → Click "Sign up"
```
✅ Should see: Clerk sign-up form

**Create test account:**
```
Email: test@example.com
Password: Test123456!
```
✅ Should redirect to: `/onboarding`

---

### Test 3: Complete Onboarding
```
Fill out the form:
- Name: Test User
- Industry: Technology - Software Development
- Skills: React, JavaScript, TypeScript
- Experience: 3 years
```
✅ Should redirect to: `/dashboard`

---

### Test 4: View Dashboard
```
You should see:
- Career insights
- Salary ranges chart
- Skills distribution
- Industry trends
```
✅ Everything loaded with purple gradients!

---

### Test 5: Application Tracker (Phase 1)
```
Click "Applications" in navigation
OR
Go to: http://localhost:3000/applications
```
✅ Should see:
- Kanban board with 4 columns
- Stats cards at top
- "Add Application" button

---

### Test 6: Job Analyzer (Phase 1)
```
Click "Job Analyzer" in navigation
OR
Go to: http://localhost:3000/job-analyzer
```

**Test the AI:**
1. Paste this job description:
```
Senior Full Stack Developer
We're looking for an experienced developer with:
- 5+ years of experience
- React, Node.js, TypeScript
- PostgreSQL, MongoDB
- AWS, Docker, Kubernetes
- $120k-160k salary
```

2. Click "Analyze with AI"
3. Wait 2-3 seconds

✅ Should see:
- Match percentage
- Matched vs missing skills
- AI recommendations
- Radar chart
- Beautiful purple gradients!

---

## 🎉 SUCCESS!

If all tests passed, you're ready to go!

**Your app is working with:**
✅ Authentication (Clerk)
✅ Database (Neon PostgreSQL)
✅ AI Analysis (Google Gemini)
✅ Beautiful UI (Phase 1 features)

---

## 📊 Usage Dashboard Links

**Bookmark these to monitor usage:**

### Clerk Dashboard
```
https://dashboard.clerk.com
```
- View total users
- See sign-ins
- Monitor API usage
- Current: 0 / 10,000 users

### Google AI Studio
```
https://aistudio.google.com/app/apikey
```
- View API usage
- Manage keys
- See quota
- Current: 0 / 60 requests per minute

### Neon Console
```
https://console.neon.tech
```
- View database
- Check storage usage (0 / 10 GB)
- Monitor queries
- Manage projects

### Prisma Studio (Local)
```bash
npx prisma studio
```
- Visual database editor
- View all tables
- Edit data
- Run queries
- Opens at: http://localhost:5555

---

## 🐛 Common Issues

### Issue: "Cannot find module"
```bash
rm -rf node_modules package-lock.json
npm install
```

### Issue: "Port 3000 already in use"
```bash
# Kill the process
lsof -ti:3000 | xargs kill -9
npm run dev
```

### Issue: Prisma connection error
```bash
# Check your DATABASE_URL
cat .env | grep DATABASE_URL

# Should have quotes!
DATABASE_URL="postgresql://..."

# Regenerate
npx prisma generate
npx prisma db push
```

### Issue: Clerk error still showing
```bash
# Make sure keys are in .env
cat .env | grep CLERK

# Restart dev server
# Press Ctrl+C to stop
npm run dev
```

---

## 💡 Pro Tips

1. **View database visually:**
   ```bash
   npx prisma studio
   ```
   Opens at http://localhost:5555

2. **Check all environment variables:**
   ```bash
   cat .env
   ```

3. **Clear Next.js cache:**
   ```bash
   rm -rf .next
   npm run dev
   ```

4. **See database structure:**
   ```bash
   npx prisma studio
   ```

---

## 🎯 What You Built

You now have a fully functional AI Career Coach with:

✅ **Application Tracker**
- Drag-and-drop Kanban board
- Analytics dashboard
- Match score tracking

✅ **AI Job Analyzer**
- Paste any job description
- Get match percentage
- AI recommendations
- Skills gap analysis

✅ **Resume Builder**
- AI-powered generation
- Multiple templates
- PDF export

✅ **Cover Letter Generator**
- Personalized content
- Company research
- Save & edit

✅ **Mock Interviews**
- Industry-specific questions
- Performance tracking
- Instant feedback

---

## 🚀 Start Using!

1. Track applications: `/applications`
2. Analyze jobs: `/job-analyzer`
3. Build resume: `/resume`
4. Create cover letter: `/ai-cover-letter`
5. Practice interviews: `/interview`

**Happy job hunting!** 🎉
