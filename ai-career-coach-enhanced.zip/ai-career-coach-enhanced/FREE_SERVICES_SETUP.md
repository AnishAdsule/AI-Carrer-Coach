# 🆓 Free Services Setup Guide - Step by Step

## All services are 100% FREE with no credit card required!

---

## 1️⃣ Clerk Authentication (FREE - 10,000 users/month)

### Step 1: Sign Up
1. Go to: **https://dashboard.clerk.com/sign-up**
2. Click **"Continue with GitHub"** or **"Continue with Google"**
3. No credit card required! ✅

### Step 2: Create Application
1. Click **"+ Create application"**
2. Enter application name: `AI Career Coach`
3. Choose sign-in options:
   - ✅ Email
   - ✅ Google
   - ✅ GitHub (optional)
4. Click **"Create application"**

### Step 3: Get API Keys
1. You'll see a screen with your API keys
2. Copy both keys:
   - `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` (starts with `pk_test_`)
   - `CLERK_SECRET_KEY` (starts with `sk_test_`)

### Step 4: Add to .env
Open your `.env` file and paste:

```env
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
CLERK_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL=/onboarding
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL=/onboarding
```

### ✅ Done! Clerk is configured
- Free tier: 10,000 monthly active users
- No expiration
- Full features included

---

## 2️⃣ Google Gemini AI (FREE - 60 requests/minute)

### Step 1: Get API Key
1. Go to: **https://aistudio.google.com/app/apikey**
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Select **"Create API key in new project"**
5. Copy the API key (starts with `AIzaSy`)

### Step 2: Add to .env
```env
GEMINI_API_KEY=AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### ✅ Done! Gemini AI is ready
- Free tier: 60 requests per minute
- 1,500 requests per day
- No credit card required
- Perfect for job analysis feature!

**Note:** Keep your API key secret and never commit it to GitHub!

---

## 3️⃣ Neon Database (FREE - 10GB storage)

### Step 1: Sign Up
1. Go to: **https://neon.tech**
2. Click **"Sign up"**
3. Choose **"Continue with GitHub"** or **"Continue with Google"**
4. No credit card required! ✅

### Step 2: Create Project
1. Click **"Create a project"**
2. Enter project name: `ai-career-coach`
3. Select region closest to you (e.g., US East, EU West, Asia Pacific)
4. Click **"Create project"**

### Step 3: Get Connection String
1. After project creation, you'll see the dashboard
2. Click **"Connection string"** tab
3. Copy the connection string (it looks like this):
   ```
   postgresql://username:password@ep-xxxxx.region.aws.neon.tech/neondb?sslmode=require
   ```

### Step 4: Add to .env
```env
DATABASE_URL="postgresql://username:password@ep-xxxxx.region.aws.neon.tech/neondb?sslmode=require"
```

### ✅ Done! Database is ready
- Free tier: 10 GB storage
- Autoscaling compute
- No credit card required
- Serverless PostgreSQL

**Pro Tip:** You can access your database using:
- Neon Console (web interface)
- Any PostgreSQL client
- `npx prisma studio` (built-in database viewer)

---

## 4️⃣ Inngest (OPTIONAL - FREE - 1M function runs/month)

This is optional for background jobs. You can skip this and the app will still work!

### If you want to set it up:

1. Go to: **https://www.inngest.com/sign-up**
2. Sign up with GitHub
3. Create a project
4. Get your keys from the dashboard:
   - Event Key
   - Signing Key
5. Add to `.env`:
```env
INNGEST_EVENT_KEY=your_event_key_here
INNGEST_SIGNING_KEY=your_signing_key_here
```

### Or skip it:
Just comment out or don't add the Inngest keys. The app will work fine without background jobs.

---

## 📝 Complete .env File Example

After setting up all services, your `.env` file should look like this:

```env
# Database (Neon)
DATABASE_URL="postgresql://username:password@ep-cool-cloud-123456.us-east-2.aws.neon.tech/neondb?sslmode=require"

# Clerk Authentication
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_Y2xlcmsuaW5zcGlyZWQtbW9vc2UtNzEuc2hhcmVkLmxjbC5kZXYk
CLERK_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL=/onboarding
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL=/onboarding

# Google Gemini AI
GEMINI_API_KEY=AIzaSyBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Inngest (Optional - can leave commented out)
# INNGEST_EVENT_KEY=your_key
# INNGEST_SIGNING_KEY=your_key

# Optional: App Configuration
NODE_ENV=development
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

---

## 🚀 Final Setup Steps

After adding all keys to `.env`:

```bash
# 1. Install dependencies
npm install

# 2. Generate Prisma Client
npx prisma generate

# 3. Push database schema to Neon
npx prisma db push

# 4. (Optional) View your database
npx prisma studio

# 5. Start the development server
npm run dev
```

Open **http://localhost:3000** 🎉

---

## ✅ Verification Checklist

Make sure everything is working:

### 1. Database Connection
```bash
npx prisma db push
```
✅ Should say "Your database is now in sync with your Prisma schema"

### 2. Clerk Authentication
1. Go to http://localhost:3000/sign-up
2. Try to create an account
3. ✅ Should redirect you to onboarding

### 3. Gemini AI
1. Go to http://localhost:3000/job-analyzer
2. Paste a job description
3. Click "Analyze with AI"
4. ✅ Should show analysis results

### 4. Application Tracker
1. Go to http://localhost:3000/applications
2. ✅ Should see the Kanban board

---

## 🎯 Service Limits (All FREE)

| Service | Free Tier | Limit | Need Credit Card? |
|---------|-----------|-------|-------------------|
| Clerk | 10,000 MAU/month | Unlimited apps | ❌ No |
| Gemini AI | 60 req/min | 1,500 req/day | ❌ No |
| Neon | 10 GB storage | 3 projects | ❌ No |
| Inngest | 1M runs/month | Unlimited functions | ❌ No |

**MAU = Monthly Active Users**

---

## 🔒 Security Tips

1. **Never commit `.env` to GitHub**
   - Already in `.gitignore` ✅
   - Keep your keys secret

2. **Regenerate keys if exposed**
   - Clerk: Dashboard → API Keys → Regenerate
   - Gemini: Create new key in AI Studio
   - Neon: Reset password in dashboard

3. **Use environment variables in production**
   - Vercel: Settings → Environment Variables
   - Add all keys from `.env`

---

## 🆘 Troubleshooting

### ❌ "Missing publishableKey" error
- Make sure `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` is in `.env`
- Restart dev server: `npm run dev`
- Check key starts with `pk_test_`

### ❌ Database connection error
- Check `DATABASE_URL` is correct
- Make sure Neon project is active
- Try copying connection string again

### ❌ Gemini API error
- Verify API key at https://aistudio.google.com/app/apikey
- Check you haven't exceeded rate limit (60/min)
- Make sure key starts with `AIzaSy`

### ❌ Port 3000 already in use
```bash
# Kill the process
lsof -ti:3000 | xargs kill -9

# Or use different port
npm run dev -- -p 3001
```

---

## 📊 Service Dashboards

Access your dashboards anytime:

- **Clerk**: https://dashboard.clerk.com
  - View users, sessions, logs
  - Configure authentication
  - See analytics

- **Gemini AI**: https://aistudio.google.com
  - Manage API keys
  - View usage
  - Test prompts

- **Neon**: https://console.neon.tech
  - View database
  - Check storage usage
  - Monitor queries

- **Prisma Studio**: `npx prisma studio`
  - Visual database editor
  - View/edit data
  - Run queries

---

## 🎉 You're All Set!

All services are configured and completely FREE:

✅ **Authentication** - Clerk (10,000 users/month)
✅ **AI Analysis** - Google Gemini (60 req/min)
✅ **Database** - Neon PostgreSQL (10GB)
✅ **No credit cards needed!**

Start using your AI Career Coach:
- 📊 Track applications at `/applications`
- 🤖 Analyze jobs at `/job-analyzer`
- 📄 Build resume at `/resume`
- 💼 Create cover letters at `/ai-cover-letter`
- 🎤 Practice interviews at `/interview`

**Happy job hunting!** 🚀

---

## 💡 Pro Tips

1. **Bookmark these URLs:**
   - Clerk Dashboard: https://dashboard.clerk.com
   - Neon Console: https://console.neon.tech
   - Gemini AI Studio: https://aistudio.google.com

2. **Monitor usage:**
   - Check Clerk dashboard weekly
   - Watch Gemini API quota
   - Monitor Neon storage

3. **Upgrade later if needed:**
   - All services have paid tiers
   - Upgrade when you exceed free limits
   - Start free, scale as you grow!

4. **Backup your data:**
   ```bash
   # Export database
   npx prisma db pull
   
   # Generate backup
   pg_dump $DATABASE_URL > backup.sql
   ```

---

## 📞 Support Links

- **Clerk Docs**: https://clerk.com/docs
- **Gemini Docs**: https://ai.google.dev/docs
- **Neon Docs**: https://neon.tech/docs
- **Prisma Docs**: https://www.prisma.io/docs

**Questions?** Check the docs or search in their support forums!
