"use client";

import React, { useState } from "react";
import { 
  DragDropContext, 
  Droppable, 
  Draggable 
} from "@hello-pangea/dnd";
import {
  Building2,
  MapPin,
  Calendar,
  DollarSign,
  ExternalLink,
  MoreVertical,
  Plus,
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Briefcase,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";

const ApplicationBoard = ({ applications, onUpdateStatus, onAddApplication }) => {
  const [columns, setColumns] = useState({
    applied: {
      id: "applied",
      title: "Applied",
      icon: Clock,
      color: "bg-blue-500",
      gradient: "from-blue-500 to-cyan-500",
      items: applications.filter((app) => app.status === "applied"),
    },
    interview: {
      id: "interview",
      title: "Interview",
      icon: AlertCircle,
      color: "bg-purple-500",
      gradient: "from-purple-500 to-pink-500",
      items: applications.filter((app) => app.status === "interview"),
    },
    offer: {
      id: "offer",
      title: "Offer",
      icon: TrendingUp,
      color: "bg-green-500",
      gradient: "from-green-500 to-emerald-500",
      items: applications.filter((app) => app.status === "offer"),
    },
    rejected: {
      id: "rejected",
      title: "Rejected",
      icon: XCircle,
      color: "bg-red-500",
      gradient: "from-red-500 to-orange-500",
      items: applications.filter((app) => app.status === "rejected"),
    },
  });

  const onDragEnd = (result) => {
    const { source, destination } = result;

    if (!destination) return;
    if (
      source.droppableId === destination.droppableId &&
      source.index === destination.index
    )
      return;

    const sourceColumn = columns[source.droppableId];
    const destColumn = columns[destination.droppableId];
    const sourceItems = [...sourceColumn.items];
    const destItems = [...destColumn.items];
    const [removed] = sourceItems.splice(source.index, 1);

    if (source.droppableId === destination.droppableId) {
      sourceItems.splice(destination.index, 0, removed);
      setColumns({
        ...columns,
        [source.droppableId]: {
          ...sourceColumn,
          items: sourceItems,
        },
      });
    } else {
      destItems.splice(destination.index, 0, removed);
      setColumns({
        ...columns,
        [source.droppableId]: {
          ...sourceColumn,
          items: sourceItems,
        },
        [destination.droppableId]: {
          ...destColumn,
          items: destItems,
        },
      });

      // Update status in database
      onUpdateStatus(removed.id, destination.droppableId);
    }
  };

  const ApplicationCard = ({ application, index }) => {
    const matchScoreColor =
      application.matchScore >= 80
        ? "text-green-500"
        : application.matchScore >= 60
        ? "text-yellow-500"
        : "text-red-500";

    return (
      <Draggable draggableId={application.id} index={index}>
        {(provided, snapshot) => (
          <div
            ref={provided.innerRef}
            {...provided.draggableProps}
            {...provided.dragHandleProps}
            className={`mb-3 ${snapshot.isDragging ? "opacity-50" : ""}`}
          >
            <Card className="card-hover border-2 bg-card/80 backdrop-blur-sm group cursor-grab active:cursor-grabbing">
              <CardContent className="p-4 space-y-3">
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-base line-clamp-1 group-hover:text-primary transition-colors">
                      {application.jobTitle}
                    </h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Building2 className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                      <p className="text-sm text-muted-foreground line-clamp-1">
                        {application.company}
                      </p>
                    </div>
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>View Details</DropdownMenuItem>
                      <DropdownMenuItem>Edit</DropdownMenuItem>
                      <DropdownMenuItem>Add Note</DropdownMenuItem>
                      <DropdownMenuItem className="text-red-500">
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {/* Location & Salary */}
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  {application.location && (
                    <div className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      <span className="line-clamp-1">{application.location}</span>
                    </div>
                  )}
                  {application.salary && (
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-3 h-3" />
                      <span>{application.salary}</span>
                    </div>
                  )}
                </div>

                {/* Match Score */}
                {application.matchScore && (
                  <div className="flex items-center justify-between p-2 rounded-lg bg-secondary/50">
                    <span className="text-xs font-medium">Match Score</span>
                    <span className={`text-sm font-bold ${matchScoreColor}`}>
                      {application.matchScore}%
                    </span>
                  </div>
                )}

                {/* Date & Link */}
                <div className="flex items-center justify-between pt-2 border-t border-border">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="w-3 h-3" />
                    <span>{format(new Date(application.appliedDate), "MMM d")}</span>
                  </div>
                  {application.jobUrl && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      asChild
                    >
                      <a
                        href={application.jobUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </Draggable>
    );
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Object.values(columns).map((column) => {
          const Icon = column.icon;
          return (
            <Card key={column.id} className="card-hover border-2">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{column.title}</p>
                    <p className="text-2xl font-bold mt-1">{column.items.length}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${column.gradient} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Kanban Board */}
      <DragDropContext onDragEnd={onDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Object.values(columns).map((column) => {
            const Icon = column.icon;
            return (
              <div key={column.id} className="flex flex-col">
                {/* Column Header */}
                <div className={`flex items-center justify-between p-4 rounded-t-xl bg-gradient-to-br ${column.gradient} text-white`}>
                  <div className="flex items-center gap-2">
                    <Icon className="w-5 h-5" />
                    <h3 className="font-bold">{column.title}</h3>
                  </div>
                  <Badge variant="secondary" className="bg-white/20 text-white border-0">
                    {column.items.length}
                  </Badge>
                </div>

                {/* Droppable Column */}
                <Droppable droppableId={column.id}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={`flex-1 p-4 rounded-b-xl border-2 border-t-0 min-h-[500px] transition-colors ${
                        snapshot.isDraggingOver
                          ? "bg-primary/5 border-primary"
                          : "bg-secondary/30 border-border"
                      }`}
                    >
                      {column.items.map((item, index) => (
                        <ApplicationCard
                          key={item.id}
                          application={item}
                          index={index}
                        />
                      ))}
                      {provided.placeholder}

                      {/* Add Button */}
                      {column.id === "applied" && (
                        <Button
                          variant="outline"
                          className="w-full border-dashed"
                          onClick={onAddApplication}
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add Application
                        </Button>
                      )}
                    </div>
                  )}
                </Droppable>
              </div>
            );
          })}
        </div>
      </DragDropContext>
    </div>
  );
};

export default ApplicationBoard;
